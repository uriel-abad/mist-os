/**
 * MIST OS v2.0 — Google Apps Script backend
 * Run setupMistOS() once from a spreadsheet-bound Apps Script project.
 */

const MIST_OS_VERSION = "2.1.0";
const SCHEMA_VERSION = "MIST-OS-2.1";
const ORDER_PREFIX = "MIST";
const DUPLICATE_WINDOW_MINUTES = 30;
const ADMIN_KEY_PROPERTY = "MIST_OS_ADMIN_KEY";
const SPREADSHEET_ID_PROPERTY = "MIST_OS_SPREADSHEET_ID";

const SHEETS = Object.freeze({
  PRODUCTS: "Products",
  CATALOG: "Website Catalog",
  ORDERS: "Orders",
  ITEMS: "Order Items",
  INVENTORY: "Inventory",
  CUSTOMERS: "Customers",
  SETTINGS: "Website Settings",
  ERRORS: "Error Log"
});

const PRODUCT_HEADERS = ["Product ID", "SKU", "Product Name", "Color", "Size", "Price", "Active"];
const CATALOG_HEADERS = [
  "Product ID", "Slug", "Product Name", "Description", "Badge", "Default Color",
  "Color", "Color Code", "Front Image URL", "Back Image URL", "Sort Order", "Featured", "Active"
];
const ORDER_HEADERS = [
  "Submitted At", "Order Number", "Customer Name", "Email", "Mobile", "Delivery Address",
  "Total Quantity", "Subtotal", "Status", "Payment Status", "Duplicate Check",
  "Inventory State", "Notes", "Order Signature"
];
const ITEM_HEADERS = [
  "Submitted At", "Order Number", "Product ID", "SKU", "Product Name", "Color", "Size",
  "Quantity", "Unit Price", "Line Total"
];
const INVENTORY_HEADERS = ["SKU", "Product Name", "Color", "Size", "Stock", "Reserved", "Available"];
const CUSTOMER_HEADERS = ["Email", "Customer Name", "Mobile", "Orders", "Lifetime Spend", "Last Order"];
const SETTINGS_HEADERS = ["Key", "Value"];
const ERROR_HEADERS = ["Timestamp", "Function", "Order Number", "Error", "Details"];

const ORDER_STATUSES = ["New", "Suspicious", "Confirmed", "Packed", "Shipped", "Delivered", "Cancelled", "Duplicate"];
const PAYMENT_STATUSES = ["Pending", "Paid", "COD", "Refunded"];
const ALLOWED_TRANSITIONS = {
  New: ["Confirmed", "Cancelled", "Suspicious", "Duplicate"],
  Suspicious: ["Confirmed", "Cancelled", "Duplicate"],
  Confirmed: ["Packed", "Cancelled"],
  Packed: ["Shipped", "Cancelled"],
  Shipped: ["Delivered"],
  Delivered: [], Cancelled: [], Duplicate: []
};

const DEFAULT_PRODUCTS = (() => {
  const rows = [];
  const sizes = ["XS", "S", "M", "L", "XL"];
  const colors = [{name:"White",code:"WHT"},{name:"Black",code:"BLK"},{name:"Light Pink",code:"PNK"}];
  colors.forEach(c => sizes.forEach(size => rows.push(["AFS", `AFS-${c.code}-${size}`, "AirForm Studio Set", c.name, size, 899, "Yes"])));
  return rows;
})();

const DEFAULT_CATALOG = [
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","White","WHT","images/products/airform-studio-set/white/front.png","images/products/airform-studio-set/white/back.png",1,"Yes","Yes"],
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","Black","BLK","images/products/airform-studio-set/black/front.png","images/products/airform-studio-set/black/back.png",1,"Yes","Yes"],
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","Light Pink","PNK","images/products/airform-studio-set/light-pink/front.png","images/products/airform-studio-set/light-pink/back.png",1,"Yes","Yes"]
];

const DEFAULT_SETTINGS = [
  ["store_name", "MIST"],
  ["hero_title", "Move Light. Move Free."],
  ["hero_subtitle", "Activewear made for movement, confidence, and everyday life."],
  ["hero_button", "Shop the Collection"],
  ["hero_eyebrow", "The Airform Collection"],
  ["announcement_text", "MIST CATALOGUE · ORDERS ARE CONFIRMED MANUALLY BEFORE PAYMENT"],
  ["messenger_username", "marichris.milanes"],
  ["instagram_username", "Chrissygotosleep"],
  ["currency", "PHP"]
];


/**
 * 01 Setup
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function setupMistOS() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error("Open Apps Script from the target Google Sheet using Extensions → Apps Script.");
  PropertiesService.getScriptProperties().setProperty(SPREADSHEET_ID_PROPERTY, ss.getId());

  const sheets = prepareSheets_(ss);
  seedIfEmpty_(sheets.products, DEFAULT_PRODUCTS);
  seedIfEmpty_(sheets.catalog, DEFAULT_CATALOG);
  seedIfEmpty_(sheets.settings, DEFAULT_SETTINGS);
  syncInventoryFromProducts_();
  rebuildCustomers_();
  formatSheets_(sheets);

  let key = PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY);
  if (!key) {
    key = Utilities.getUuid().replace(/-/g, "");
    PropertiesService.getScriptProperties().setProperty(ADMIN_KEY_PROPERTY, key);
  }
  SpreadsheetApp.flush();
  console.log("MIST OS admin key: " + key);
  return { ok: true, version: MIST_OS_VERSION, adminKey: key, sheets: Object.values(SHEETS) };
}
function getAdminKey() {
  return PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY) || "Run setupMistOS first.";
}
function setAdminKey(newKey) {
  const key = String(newKey || "").trim();
  if (key.length < 12) throw new Error("Use an admin key with at least 12 characters.");
  PropertiesService.getScriptProperties().setProperty(ADMIN_KEY_PROPERTY, key);
  return "Admin key updated.";
}
function prepareSheets_(ss) {
  return {
    products: prepareSheet_(ss, SHEETS.PRODUCTS, PRODUCT_HEADERS), catalog: prepareSheet_(ss, SHEETS.CATALOG, CATALOG_HEADERS),
    orders: prepareSheet_(ss, SHEETS.ORDERS, ORDER_HEADERS), items: prepareSheet_(ss, SHEETS.ITEMS, ITEM_HEADERS),
    inventory: prepareSheet_(ss, SHEETS.INVENTORY, INVENTORY_HEADERS), customers: prepareSheet_(ss, SHEETS.CUSTOMERS, CUSTOMER_HEADERS),
    settings: prepareSheet_(ss, SHEETS.SETTINGS, SETTINGS_HEADERS), errors: prepareSheet_(ss, SHEETS.ERRORS, ERROR_HEADERS)
  };
}
function prepareSheet_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) sheet.getRange(1,1,1,headers.length).setValues([headers]);
  return sheet;
}
function seedIfEmpty_(sheet, rows) {
  if (sheet.getLastRow() <= 1 && rows.length) sheet.getRange(2,1,rows.length,rows[0].length).setValues(rows);
}
function formatSheets_(s) {
  [s.products,s.catalog,s.orders,s.items,s.inventory,s.customers,s.settings,s.errors].forEach(sheet => {
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,sheet.getLastColumn()).setFontWeight("bold").setBackground("#111111").setFontColor("#ffffff");
  });
  s.products.getRange("F:F").setNumberFormat('₱#,##0.00');
  s.orders.getRange("H:H").setNumberFormat('₱#,##0.00');
  s.items.getRange("I:J").setNumberFormat('₱#,##0.00');
  s.customers.getRange("E:E").setNumberFormat('₱#,##0.00');
  s.inventory.getRange("E:G").setNumberFormat("0");
  setValidation_(s.orders,9,ORDER_STATUSES); setValidation_(s.orders,10,PAYMENT_STATUSES);
  setValidation_(s.products,7,["Yes","No"]); setValidation_(s.catalog,12,["Yes","No"]); setValidation_(s.catalog,13,["Yes","No"]);
}
function setValidation_(sheet, column, values) {
  sheet.getRange(2,column,Math.max(sheet.getMaxRows()-1,1),1).setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(values,true).build());
}


function testMistOS() {
  const ss = getSpreadsheet_();
  const missing = Object.values(SHEETS).filter(name => !ss.getSheetByName(name));
  const catalog = buildPublicCatalog_();
  const inventory = rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, false);
  return {
    ok: missing.length === 0 && catalog.length > 0,
    version: MIST_OS_VERSION,
    schema: SCHEMA_VERSION,
    spreadsheet: ss.getName(),
    missingSheets: missing,
    catalogProducts: catalog.length,
    inventoryRows: inventory.length
  };
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("MIST OS")
    .addItem("Run setup", "setupMistOS")
    .addItem("Run system test", "testMistOS")
    .addItem("Show admin key", "showAdminKey")
    .addToUi();
}

function showAdminKey() {
  const key = getAdminKey();
  SpreadsheetApp.getUi().alert(
    "MIST OS Admin Key",
    "Keep this private. Enter it only in the admin portal.\\n\\n" + key,
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}


/**
 * 02 WebApp
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function doGet(e) {
  try {
    const action = String(e && e.parameter && e.parameter.action || "health").toLowerCase();
    if (action === "catalog") return json_(publicCatalogResponse_());
    if (action === "settings") return json_({ ok: true, settings: settingsObject_() });
    return json_({ ok: true, message: "MIST OS API is running.", version: MIST_OS_VERSION, schema: SCHEMA_VERSION });
  } catch (error) {
    return json_({ ok: false, error: errorMessage_(error) });
  }
}
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const payload = parsePayload_(e);
    const action = String(payload.action || "createOrder");
    if (action === "createOrder") return json_(createOrder_(payload));

    requireAdmin_(payload.adminKey);
    if (action === "dashboard") return json_({ ok: true, dashboard: dashboardData_() });
    if (action === "orders") return json_({ ok: true, orders: rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, true) });
    if (action === "products") return json_({
      ok: true,
      products: rowsAsObjects_(SHEETS.PRODUCTS, PRODUCT_HEADERS, true),
      catalog: rowsAsObjects_(SHEETS.CATALOG, CATALOG_HEADERS, true)
    });
    if (action === "inventory") return json_({ ok: true, inventory: rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, true) });
    if (action === "customers") return json_({ ok: true, customers: rowsAsObjects_(SHEETS.CUSTOMERS, CUSTOMER_HEADERS, true) });
    if (action === "websiteSettings") return json_({ ok: true, settings: settingsObject_() });
    if (action === "updateOrderStatus") return json_(updateOrderStatus_(payload.orderNumber, payload.status));
    if (action === "updatePaymentStatus") return json_(updatePaymentStatus_(payload.orderNumber, payload.paymentStatus));
    if (action === "saveProduct") return json_(saveProduct_(payload.product));
    if (action === "saveCatalogEntry") return json_(saveCatalogEntry_(payload.entry));
    if (action === "updateStock") return json_(updateStock_(payload.sku, payload.stock));
    if (action === "saveSetting") return json_(saveSetting_(payload.key, payload.value));
    if (action === "syncInventory") return json_({ ok: true, added: syncInventoryFromProducts_() });
    if (action === "rebuildCustomers") return json_({ ok: true, customers: rebuildCustomers_() });
    throw new Error("Unknown action: " + action);
  } catch (error) {
    logError_("doPost", "", error, e && e.postData ? e.postData.contents : "");
    return json_({ ok: false, error: errorMessage_(error) });
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}


/**
 * 03 Orders
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function createOrder_(payload) {
  validateCustomer_(payload);
  const ss = getSpreadsheet_();
  const products = productMap_();
  const items = validateAndPriceItems_(payload.items, products);
  const submittedAt = new Date();
  const signature = orderSignature_(payload, items);
  const duplicate = findLikelyDuplicate_(signature, submittedAt);
  const orderNumber = nextOrderNumber_();
  const qty = items.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
  const orders = ss.getSheetByName(SHEETS.ORDERS);
  orders.appendRow([
    submittedAt, orderNumber, payload.name.trim(), payload.email.trim(), payload.mobile.trim(), payload.address.trim(),
    qty, subtotal, duplicate ? "Suspicious" : "New", "Pending",
    duplicate ? "Possible duplicate of " + duplicate : "Clear", "NONE", String(payload.notes || "").trim(), signature
  ]);
  const itemsSheet = ss.getSheetByName(SHEETS.ITEMS);
  const rows = items.map(item => [submittedAt, orderNumber, item.productId, item.sku, item.name, item.color, item.size, item.qty, item.price, item.lineTotal]);
  itemsSheet.getRange(itemsSheet.getLastRow() + 1, 1, rows.length, ITEM_HEADERS.length).setValues(rows);
  rebuildCustomers_();
  return { ok: true, orderNumber, totalQuantity: qty, subtotal, possibleDuplicate: Boolean(duplicate) };
}
function updateOrderStatus_(orderNumber, newStatus) {
  const status = String(newStatus || "").trim();
  if (!ORDER_STATUSES.includes(status)) throw new Error("Invalid order status.");
  const ss = getSpreadsheet_();
  const orders = ss.getSheetByName(SHEETS.ORDERS);
  const row = findOrderRow_(orders, orderNumber);
  if (!row) throw new Error("Order not found: " + orderNumber);
  const oldStatus = String(orders.getRange(row, 9).getValue() || "New");
  if (oldStatus !== status && !(ALLOWED_TRANSITIONS[oldStatus] || []).includes(status)) {
    throw new Error(`Invalid status change: ${oldStatus} → ${status}`);
  }
  const currentState = String(orders.getRange(row, 12).getValue() || "NONE");
  const targetState = inventoryStateForStatus_(status);
  if (currentState === "SOLD" && targetState !== "SOLD") throw new Error("This order is already deducted from stock. Process a return manually.");
  if (currentState !== targetState) {
    transitionInventory_(orderItems_(orderNumber), currentState, targetState);
    orders.getRange(row, 12).setValue(targetState);
  }
  orders.getRange(row, 9).setValue(status);
  return { ok: true, orderNumber, status, inventoryState: targetState };
}
function updatePaymentStatus_(orderNumber, paymentStatus) {
  const status = String(paymentStatus || "").trim();
  if (!PAYMENT_STATUSES.includes(status)) throw new Error("Invalid payment status.");
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.ORDERS);
  const row = findOrderRow_(sheet, orderNumber);
  if (!row) throw new Error("Order not found: " + orderNumber);
  sheet.getRange(row, 10).setValue(status);
  rebuildCustomers_();
  return { ok: true, orderNumber, paymentStatus: status };
}
function orderItems_(orderNumber) {
  return rowsAsObjects_(SHEETS.ITEMS, ITEM_HEADERS, false)
    .filter(r => r["Order Number"] === orderNumber)
    .map(r => ({ sku: String(r.SKU).toUpperCase(), quantity: Number(r.Quantity || 0) }));
}
function validateCustomer_(p) {
  if (!p.name || !p.email || !p.mobile || !p.address) throw new Error("Required customer information is missing.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(p.email))) throw new Error("Enter a valid email address.");
}
function orderSignature_(p, items) {
  return [String(p.email).toLowerCase(), normalizePhone_(p.mobile), items.map(i => `${i.sku}|${i.qty}`).sort().join(";")].join("::");
}
function findLikelyDuplicate_(signature, submittedAt) {
  const rows = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const cutoff = submittedAt.getTime() - DUPLICATE_WINDOW_MINUTES * 60000;
  for (let i = rows.length - 1; i >= 0; i--) {
    const when = new Date(rows[i]["Submitted At"]).getTime();
    if (when && when < cutoff) break;
    if (rows[i]["Order Signature"] === signature) return rows[i]["Order Number"];
  }
  return "";
}
function nextOrderNumber_() {
  const year = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy");
  const key = "ORDER_COUNTER_" + year;
  const props = PropertiesService.getScriptProperties();
  const next = Number(props.getProperty(key) || 0) + 1;
  props.setProperty(key, String(next));
  return `${ORDER_PREFIX}-${year}-${String(next).padStart(4,"0")}`;
}


/**
 * 04 Products
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function saveProduct_(product) {
  const p = product || {};
  const values = [
    String(p.productId || "").trim(), String(p.sku || "").trim().toUpperCase(), String(p.name || "").trim(),
    String(p.color || "").trim(), String(p.size || "").trim(), Number(p.price), yesNo_(p.active)
  ];
  if (!values[0] || !values[1] || !values[2] || !values[3] || !values[4] || !Number.isFinite(values[5])) throw new Error("Complete all product fields.");
  upsertByKey_(SHEETS.PRODUCTS, PRODUCT_HEADERS, 2, values);
  syncInventoryFromProducts_();
  return { ok: true, sku: values[1] };
}
function saveCatalogEntry_(entry) {
  const e = entry || {};
  const values = [
    String(e.productId || "").trim(), String(e.slug || "").trim(), String(e.name || "").trim(),
    String(e.description || "").trim(), String(e.badge || "").trim(), String(e.defaultColor || "").trim(),
    String(e.color || "").trim(), String(e.colorCode || "").trim().toUpperCase(),
    String(e.frontImage || "").trim(), String(e.backImage || "").trim(), Number(e.sortOrder || 999),
    yesNo_(e.featured), yesNo_(e.active)
  ];
  if (!values[0] || !values[1] || !values[2] || !values[6] || !values[7] || !values[8] || !values[9]) throw new Error("Complete the required catalog fields.");
  const key = values[0] + "|" + values[6];
  upsertByCompositeKey_(SHEETS.CATALOG, CATALOG_HEADERS, row => String(row[0]) + "|" + String(row[6]), key, values);
  return { ok: true, productId: values[0], color: values[6] };
}
function saveSetting_(key, value) {
  const k = String(key || "").trim();
  if (!k) throw new Error("Setting key is required.");
  upsertByKey_(SHEETS.SETTINGS, SETTINGS_HEADERS, 1, [k, String(value || "")]);
  return { ok: true, key: k, value: String(value || "") };
}
function publicCatalogResponse_() {
  return { ok: true, version: MIST_OS_VERSION, settings: settingsObject_(), products: buildPublicCatalog_() };
}
function buildPublicCatalog_() {
  const catalog = rowsAsObjects_(SHEETS.CATALOG, CATALOG_HEADERS, false);
  const products = productMap_();
  const grouped = {};
  catalog.forEach(row => {
    if (!isYes_(row.Active)) return;
    const productId = String(row["Product ID"] || "");
    const color = String(row.Color || "");
    const variants = Object.values(products).filter(v => v.active && v.productId === productId && v.color === color);
    if (!variants.length) return;
    if (!grouped[productId]) grouped[productId] = {
      id: row.Slug, productCode: productId, name: row["Product Name"], description: row.Description,
      badge: row.Badge, defaultColor: row["Default Color"], price: Math.min(...variants.map(v => v.price)),
      sizes: [], colors: {}, sortOrder: Number(row["Sort Order"] || 999), featured: isYes_(row.Featured)
    };
    variants.forEach(v => { if (!grouped[productId].sizes.includes(v.size)) grouped[productId].sizes.push(v.size); });
    grouped[productId].colors[color] = { code: row["Color Code"], front: row["Front Image URL"], back: row["Back Image URL"] };
  });
  const sizeOrder = ["XXS","XS","S","M","L","XL","XXL"];
  return Object.values(grouped).map(p => {
    p.sizes.sort((a,b) => sizeOrder.indexOf(a) - sizeOrder.indexOf(b));
    if (!p.colors[p.defaultColor]) p.defaultColor = Object.keys(p.colors)[0] || "";
    return p;
  }).sort((a,b) => a.sortOrder - b.sortOrder);
}
function productMap_() {
  const map = {};
  rowsAsObjects_(SHEETS.PRODUCTS, PRODUCT_HEADERS, false).forEach(r => {
    const sku = String(r.SKU || "").toUpperCase();
    if (!sku) return;
    map[sku] = { productId: r["Product ID"], sku, name: r["Product Name"], color: r.Color, size: r.Size, price: Number(r.Price || 0), active: isYes_(r.Active) };
  });
  return map;
}
function validateAndPriceItems_(rawItems, catalog) {
  if (!Array.isArray(rawItems) || !rawItems.length) throw new Error("The order has no items.");
  return rawItems.map(raw => {
    const sku = String(raw.sku || "").toUpperCase();
    const qty = Number(raw.qty);
    const p = catalog[sku];
    if (!p || !p.active || !Number.isInteger(qty) || qty < 1) throw new Error("Invalid or unavailable item: " + sku);
    return { ...p, qty, lineTotal: p.price * qty };
  });
}


/**
 * 05 Inventory
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function updateStock_(sku, stock) {
  const key = String(sku || "").trim().toUpperCase();
  const value = Number(stock);
  if (!key || !Number.isInteger(value) || value < 0) throw new Error("Stock must be a whole number of zero or higher.");
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  const row = findRowByValue_(sheet, 1, key);
  if (!row) throw new Error("SKU not found in Inventory: " + key);
  const reserved = Number(sheet.getRange(row, 6).getValue() || 0);
  if (value < reserved) throw new Error("Stock cannot be lower than reserved quantity.");
  sheet.getRange(row, 5, 1, 3).setValues([[value, reserved, value - reserved]]);
  return { ok: true, sku: key, stock: value, reserved, available: value - reserved };
}
function syncInventoryFromProducts_() {
  const ss = getSpreadsheet_();
  const products = productMap_();
  const sheet = ss.getSheetByName(SHEETS.INVENTORY);
  const existing = inventoryMap_();
  const rows = [];
  Object.values(products).forEach(p => {
    if (p.active && !existing[p.sku]) rows.push([p.sku, p.name, p.color, p.size, 0, 0, 0]);
  });
  if (rows.length) sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, INVENTORY_HEADERS.length).setValues(rows);
  return rows.length;
}
function transitionInventory_(items, fromState, toState) {
  if (fromState === "NONE" && toState === "RESERVED") return adjustInventory_(items, 0, 1);
  if (fromState === "RESERVED" && toState === "NONE") return adjustInventory_(items, 0, -1);
  if (fromState === "RESERVED" && toState === "SOLD") return adjustInventory_(items, -1, -1);
  if (fromState === "NONE" && toState === "SOLD") return adjustInventory_(items, -1, 0);
  throw new Error(`Unsupported inventory transition: ${fromState} → ${toState}`);
}
function adjustInventory_(items, stockMultiplier, reservedMultiplier) {
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  const map = inventoryMap_();
  const grouped = {};
  items.forEach(i => { grouped[i.sku] = (grouped[i.sku] || 0) + Number(i.quantity || 0); });
  const changes = [];
  Object.keys(grouped).forEach(sku => {
    const record = map[sku];
    if (!record) throw new Error("SKU missing from Inventory: " + sku);
    const stock = Number(record.values[4] || 0);
    const reserved = Number(record.values[5] || 0);
    const newStock = stock + stockMultiplier * grouped[sku];
    const newReserved = reserved + reservedMultiplier * grouped[sku];
    if (newStock < 0 || newReserved < 0 || newStock - newReserved < 0) throw new Error("Insufficient stock for " + sku);
    changes.push([record.row, newStock, newReserved, newStock - newReserved]);
  });
  changes.forEach(c => sheet.getRange(c[0], 5, 1, 3).setValues([[c[1],c[2],c[3]]]));
}
function inventoryStateForStatus_(status) {
  if (status === "Confirmed" || status === "Packed") return "RESERVED";
  if (status === "Shipped" || status === "Delivered") return "SOLD";
  return "NONE";
}
function inventoryMap_() {
  const map = {};
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  if (sheet.getLastRow() < 2) return map;
  sheet.getRange(2,1,sheet.getLastRow()-1,INVENTORY_HEADERS.length).getValues().forEach((r,i) => {
    const sku = String(r[0] || "").toUpperCase(); if (sku) map[sku] = { row: i+2, values: r };
  });
  return map;
}


/**
 * 06 Customers
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function rebuildCustomers_() {
  const ss = getSpreadsheet_();
  const orders = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const map = {};
  orders.forEach(o => {
    const email = String(o.Email || "").toLowerCase();
    if (!email) return;
    if (!map[email]) map[email] = { email, name: o["Customer Name"], mobile: o.Mobile, orders: 0, spend: 0, last: o["Submitted At"] };
    map[email].orders += 1;
    if (o["Payment Status"] === "Paid") map[email].spend += Number(o.Subtotal || 0);
    if (new Date(o["Submitted At"]) > new Date(map[email].last)) map[email].last = o["Submitted At"];
  });
  const sheet = ss.getSheetByName(SHEETS.CUSTOMERS);
  if (sheet.getLastRow() > 1) sheet.getRange(2, 1, sheet.getLastRow() - 1, CUSTOMER_HEADERS.length).clearContent();
  const rows = Object.values(map).map(c => [c.email, c.name, c.mobile, c.orders, c.spend, c.last]);
  if (rows.length) sheet.getRange(2, 1, rows.length, CUSTOMER_HEADERS.length).setValues(rows);
  return rows.length;
}


/**
 * 07 Reports
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function dashboardData_() {
  const orders = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const inventory = rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, false);
  const paid = orders.filter(o => o["Payment Status"] === "Paid");
  const byStatus = {};
  ORDER_STATUSES.forEach(s => byStatus[s] = orders.filter(o => o.Status === s).length);
  return {
    totalOrders: orders.length,
    paidRevenue: paid.reduce((s,o) => s + Number(o.Subtotal || 0), 0),
    byStatus,
    lowStock: inventory.filter(i => String(i.SKU) && Number(i.Available) >= 0 && Number(i.Available) <= 5).length,
    outOfStock: inventory.filter(i => String(i.SKU) && Number(i.Available) === 0).length,
    totalStock: inventory.reduce((s,i) => s + Number(i.Stock || 0), 0),
    reserved: inventory.reduce((s,i) => s + Number(i.Reserved || 0), 0),
    available: inventory.reduce((s,i) => s + Number(i.Available || 0), 0)
  };
}


/**
 * 08 Utilities
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function rowsAsObjects_(sheetName, headers, display) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = display ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getDisplayValues() : sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  return values.filter(r => r.some(v => v !== "")).map(r => Object.fromEntries(headers.map((h,i) => [h,r[i]])));
}
function settingsObject_() {
  const out = {};
  rowsAsObjects_(SHEETS.SETTINGS, SETTINGS_HEADERS, false).forEach(r => out[String(r.Key)] = r.Value);
  return out;
}
function upsertByKey_(sheetName, headers, keyColumn, values) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  const row = findRowByValue_(sheet, keyColumn, values[keyColumn-1]);
  if (row) sheet.getRange(row,1,1,headers.length).setValues([values]); else sheet.appendRow(values);
}
function upsertByCompositeKey_(sheetName, headers, keyFn, targetKey, values) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  let row = 0;
  if (sheet.getLastRow() >= 2) {
    const rows = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    const index = rows.findIndex(r => keyFn(r) === targetKey); if (index >= 0) row = index + 2;
  }
  if (row) sheet.getRange(row,1,1,headers.length).setValues([values]); else sheet.appendRow(values);
}
function findOrderRow_(sheet, orderNumber) { return findRowByValue_(sheet,2,String(orderNumber)); }
function findRowByValue_(sheet, column, value) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  const found = sheet.getRange(2,column,sheet.getLastRow()-1,1).createTextFinder(String(value)).matchEntireCell(true).findNext();
  return found ? found.getRow() : 0;
}
function requireAdmin_(provided) {
  const expected = PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY);
  if (!expected || String(provided || "") !== expected) throw new Error("Unauthorized admin request.");
}
function getSpreadsheet_() {
  const id = PropertiesService.getScriptProperties().getProperty(SPREADSHEET_ID_PROPERTY);
  if (id) return SpreadsheetApp.openById(id);
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;
  throw new Error("Run setupMistOS first.");
}
function parsePayload_(e) {
  if (!e || !e.postData || !e.postData.contents) throw new Error("No request data received.");
  return JSON.parse(e.postData.contents);
}
function normalizePhone_(v) { return String(v || "").replace(/\D/g, ""); }
function isYes_(v) { return /^(yes|true|1|active)$/i.test(String(v || "").trim()); }
function yesNo_(v) { return isYes_(v) ? "Yes" : "No"; }
function errorMessage_(e) { return String(e && e.message || e); }
function json_(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function logError_(fn, order, error, details) {
  try { getSpreadsheet_().getSheetByName(SHEETS.ERRORS).appendRow([new Date(),fn,order,errorMessage_(error),String(details || "").slice(0,1000)]); } catch (_) {}
}
