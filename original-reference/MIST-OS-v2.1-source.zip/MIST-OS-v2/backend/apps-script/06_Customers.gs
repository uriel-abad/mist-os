/**
 * 06 Customers
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function rebuildCustomers_() {
  const ss = getSpreadsheet_();
  const orders = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const map = {};
  orders.forEach(o => {
    const email = String(o.Email || "").toLowerCase();
    if (!email) return;
    if (!map[email]) map[email] = { email, name: o["Customer Name"], mobile: o.Mobile, orders: 0, spend: 0, last: o["Submitted At"] };
    map[email].orders += 1;
    if (o["Payment Status"] === "Paid") map[email].spend += Number(o.Subtotal || 0);
    if (new Date(o["Submitted At"]) > new Date(map[email].last)) map[email].last = o["Submitted At"];
  });
  const sheet = ss.getSheetByName(SHEETS.CUSTOMERS);
  if (sheet.getLastRow() > 1) sheet.getRange(2, 1, sheet.getLastRow() - 1, CUSTOMER_HEADERS.length).clearContent();
  const rows = Object.values(map).map(c => [c.email, c.name, c.mobile, c.orders, c.spend, c.last]);
  if (rows.length) sheet.getRange(2, 1, rows.length, CUSTOMER_HEADERS.length).setValues(rows);
  return rows.length;
}
