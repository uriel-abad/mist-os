/**
 * 02 WebApp
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function doGet(e) {
  try {
    const action = String(e && e.parameter && e.parameter.action || "health").toLowerCase();
    if (action === "catalog") return json_(publicCatalogResponse_());
    if (action === "settings") return json_({ ok: true, settings: settingsObject_() });
    return json_({ ok: true, message: "MIST OS API is running.", version: MIST_OS_VERSION, schema: SCHEMA_VERSION });
  } catch (error) {
    return json_({ ok: false, error: errorMessage_(error) });
  }
}
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
    const payload = parsePayload_(e);
    const action = String(payload.action || "createOrder");
    if (action === "createOrder") return json_(createOrder_(payload));

    requireAdmin_(payload.adminKey);
    if (action === "dashboard") return json_({ ok: true, dashboard: dashboardData_() });
    if (action === "orders") return json_({ ok: true, orders: rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, true) });
    if (action === "products") return json_({
      ok: true,
      products: rowsAsObjects_(SHEETS.PRODUCTS, PRODUCT_HEADERS, true),
      catalog: rowsAsObjects_(SHEETS.CATALOG, CATALOG_HEADERS, true)
    });
    if (action === "inventory") return json_({ ok: true, inventory: rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, true) });
    if (action === "customers") return json_({ ok: true, customers: rowsAsObjects_(SHEETS.CUSTOMERS, CUSTOMER_HEADERS, true) });
    if (action === "websiteSettings") return json_({ ok: true, settings: settingsObject_() });
    if (action === "updateOrderStatus") return json_(updateOrderStatus_(payload.orderNumber, payload.status));
    if (action === "updatePaymentStatus") return json_(updatePaymentStatus_(payload.orderNumber, payload.paymentStatus));
    if (action === "saveProduct") return json_(saveProduct_(payload.product));
    if (action === "saveCatalogEntry") return json_(saveCatalogEntry_(payload.entry));
    if (action === "updateStock") return json_(updateStock_(payload.sku, payload.stock));
    if (action === "saveSetting") return json_(saveSetting_(payload.key, payload.value));
    if (action === "syncInventory") return json_({ ok: true, added: syncInventoryFromProducts_() });
    if (action === "rebuildCustomers") return json_({ ok: true, customers: rebuildCustomers_() });
    throw new Error("Unknown action: " + action);
  } catch (error) {
    logError_("doPost", "", error, e && e.postData ? e.postData.contents : "");
    return json_({ ok: false, error: errorMessage_(error) });
  } finally {
    try { lock.releaseLock(); } catch (_) {}
  }
}
