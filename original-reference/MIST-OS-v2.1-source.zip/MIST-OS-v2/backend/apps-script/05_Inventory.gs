/**
 * 05 Inventory
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function updateStock_(sku, stock) {
  const key = String(sku || "").trim().toUpperCase();
  const value = Number(stock);
  if (!key || !Number.isInteger(value) || value < 0) throw new Error("Stock must be a whole number of zero or higher.");
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  const row = findRowByValue_(sheet, 1, key);
  if (!row) throw new Error("SKU not found in Inventory: " + key);
  const reserved = Number(sheet.getRange(row, 6).getValue() || 0);
  if (value < reserved) throw new Error("Stock cannot be lower than reserved quantity.");
  sheet.getRange(row, 5, 1, 3).setValues([[value, reserved, value - reserved]]);
  return { ok: true, sku: key, stock: value, reserved, available: value - reserved };
}
function syncInventoryFromProducts_() {
  const ss = getSpreadsheet_();
  const products = productMap_();
  const sheet = ss.getSheetByName(SHEETS.INVENTORY);
  const existing = inventoryMap_();
  const rows = [];
  Object.values(products).forEach(p => {
    if (p.active && !existing[p.sku]) rows.push([p.sku, p.name, p.color, p.size, 0, 0, 0]);
  });
  if (rows.length) sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, INVENTORY_HEADERS.length).setValues(rows);
  return rows.length;
}
function transitionInventory_(items, fromState, toState) {
  if (fromState === "NONE" && toState === "RESERVED") return adjustInventory_(items, 0, 1);
  if (fromState === "RESERVED" && toState === "NONE") return adjustInventory_(items, 0, -1);
  if (fromState === "RESERVED" && toState === "SOLD") return adjustInventory_(items, -1, -1);
  if (fromState === "NONE" && toState === "SOLD") return adjustInventory_(items, -1, 0);
  throw new Error(`Unsupported inventory transition: ${fromState} → ${toState}`);
}
function adjustInventory_(items, stockMultiplier, reservedMultiplier) {
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  const map = inventoryMap_();
  const grouped = {};
  items.forEach(i => { grouped[i.sku] = (grouped[i.sku] || 0) + Number(i.quantity || 0); });
  const changes = [];
  Object.keys(grouped).forEach(sku => {
    const record = map[sku];
    if (!record) throw new Error("SKU missing from Inventory: " + sku);
    const stock = Number(record.values[4] || 0);
    const reserved = Number(record.values[5] || 0);
    const newStock = stock + stockMultiplier * grouped[sku];
    const newReserved = reserved + reservedMultiplier * grouped[sku];
    if (newStock < 0 || newReserved < 0 || newStock - newReserved < 0) throw new Error("Insufficient stock for " + sku);
    changes.push([record.row, newStock, newReserved, newStock - newReserved]);
  });
  changes.forEach(c => sheet.getRange(c[0], 5, 1, 3).setValues([[c[1],c[2],c[3]]]));
}
function inventoryStateForStatus_(status) {
  if (status === "Confirmed" || status === "Packed") return "RESERVED";
  if (status === "Shipped" || status === "Delivered") return "SOLD";
  return "NONE";
}
function inventoryMap_() {
  const map = {};
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.INVENTORY);
  if (sheet.getLastRow() < 2) return map;
  sheet.getRange(2,1,sheet.getLastRow()-1,INVENTORY_HEADERS.length).getValues().forEach((r,i) => {
    const sku = String(r[0] || "").toUpperCase(); if (sku) map[sku] = { row: i+2, values: r };
  });
  return map;
}
