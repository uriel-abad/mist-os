/**
 * 01 Setup
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function setupMistOS() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error("Open Apps Script from the target Google Sheet using Extensions → Apps Script.");
  PropertiesService.getScriptProperties().setProperty(SPREADSHEET_ID_PROPERTY, ss.getId());

  const sheets = prepareSheets_(ss);
  seedIfEmpty_(sheets.products, DEFAULT_PRODUCTS);
  seedIfEmpty_(sheets.catalog, DEFAULT_CATALOG);
  seedIfEmpty_(sheets.settings, DEFAULT_SETTINGS);
  syncInventoryFromProducts_();
  rebuildCustomers_();
  formatSheets_(sheets);

  let key = PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY);
  if (!key) {
    key = Utilities.getUuid().replace(/-/g, "");
    PropertiesService.getScriptProperties().setProperty(ADMIN_KEY_PROPERTY, key);
  }
  SpreadsheetApp.flush();
  console.log("MIST OS admin key: " + key);
  return { ok: true, version: MIST_OS_VERSION, adminKey: key, sheets: Object.values(SHEETS) };
}
function getAdminKey() {
  return PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY) || "Run setupMistOS first.";
}
function setAdminKey(newKey) {
  const key = String(newKey || "").trim();
  if (key.length < 12) throw new Error("Use an admin key with at least 12 characters.");
  PropertiesService.getScriptProperties().setProperty(ADMIN_KEY_PROPERTY, key);
  return "Admin key updated.";
}
function prepareSheets_(ss) {
  return {
    products: prepareSheet_(ss, SHEETS.PRODUCTS, PRODUCT_HEADERS), catalog: prepareSheet_(ss, SHEETS.CATALOG, CATALOG_HEADERS),
    orders: prepareSheet_(ss, SHEETS.ORDERS, ORDER_HEADERS), items: prepareSheet_(ss, SHEETS.ITEMS, ITEM_HEADERS),
    inventory: prepareSheet_(ss, SHEETS.INVENTORY, INVENTORY_HEADERS), customers: prepareSheet_(ss, SHEETS.CUSTOMERS, CUSTOMER_HEADERS),
    settings: prepareSheet_(ss, SHEETS.SETTINGS, SETTINGS_HEADERS), errors: prepareSheet_(ss, SHEETS.ERRORS, ERROR_HEADERS)
  };
}
function prepareSheet_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) sheet.getRange(1,1,1,headers.length).setValues([headers]);
  return sheet;
}
function seedIfEmpty_(sheet, rows) {
  if (sheet.getLastRow() <= 1 && rows.length) sheet.getRange(2,1,rows.length,rows[0].length).setValues(rows);
}
function formatSheets_(s) {
  [s.products,s.catalog,s.orders,s.items,s.inventory,s.customers,s.settings,s.errors].forEach(sheet => {
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,sheet.getLastColumn()).setFontWeight("bold").setBackground("#111111").setFontColor("#ffffff");
  });
  s.products.getRange("F:F").setNumberFormat('₱#,##0.00');
  s.orders.getRange("H:H").setNumberFormat('₱#,##0.00');
  s.items.getRange("I:J").setNumberFormat('₱#,##0.00');
  s.customers.getRange("E:E").setNumberFormat('₱#,##0.00');
  s.inventory.getRange("E:G").setNumberFormat("0");
  setValidation_(s.orders,9,ORDER_STATUSES); setValidation_(s.orders,10,PAYMENT_STATUSES);
  setValidation_(s.products,7,["Yes","No"]); setValidation_(s.catalog,12,["Yes","No"]); setValidation_(s.catalog,13,["Yes","No"]);
}
function setValidation_(sheet, column, values) {
  sheet.getRange(2,column,Math.max(sheet.getMaxRows()-1,1),1).setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(values,true).build());
}


function testMistOS() {
  const ss = getSpreadsheet_();
  const missing = Object.values(SHEETS).filter(name => !ss.getSheetByName(name));
  const catalog = buildPublicCatalog_();
  const inventory = rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, false);
  return {
    ok: missing.length === 0 && catalog.length > 0,
    version: MIST_OS_VERSION,
    schema: SCHEMA_VERSION,
    spreadsheet: ss.getName(),
    missingSheets: missing,
    catalogProducts: catalog.length,
    inventoryRows: inventory.length
  };
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("MIST OS")
    .addItem("Run setup", "setupMistOS")
    .addItem("Run system test", "testMistOS")
    .addItem("Show admin key", "showAdminKey")
    .addToUi();
}

function showAdminKey() {
  const key = getAdminKey();
  SpreadsheetApp.getUi().alert(
    "MIST OS Admin Key",
    "Keep this private. Enter it only in the admin portal.\\n\\n" + key,
    SpreadsheetApp.getUi().ButtonSet.OK
  );
}
