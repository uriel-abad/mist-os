/**
 * 07 Reports
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function dashboardData_() {
  const orders = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const inventory = rowsAsObjects_(SHEETS.INVENTORY, INVENTORY_HEADERS, false);
  const paid = orders.filter(o => o["Payment Status"] === "Paid");
  const byStatus = {};
  ORDER_STATUSES.forEach(s => byStatus[s] = orders.filter(o => o.Status === s).length);
  return {
    totalOrders: orders.length,
    paidRevenue: paid.reduce((s,o) => s + Number(o.Subtotal || 0), 0),
    byStatus,
    lowStock: inventory.filter(i => String(i.SKU) && Number(i.Available) >= 0 && Number(i.Available) <= 5).length,
    outOfStock: inventory.filter(i => String(i.SKU) && Number(i.Available) === 0).length,
    totalStock: inventory.reduce((s,i) => s + Number(i.Stock || 0), 0),
    reserved: inventory.reduce((s,i) => s + Number(i.Reserved || 0), 0),
    available: inventory.reduce((s,i) => s + Number(i.Available || 0), 0)
  };
}
