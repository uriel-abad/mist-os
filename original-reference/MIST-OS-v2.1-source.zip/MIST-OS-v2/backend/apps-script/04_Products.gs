/**
 * 04 Products
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function saveProduct_(product) {
  const p = product || {};
  const values = [
    String(p.productId || "").trim(), String(p.sku || "").trim().toUpperCase(), String(p.name || "").trim(),
    String(p.color || "").trim(), String(p.size || "").trim(), Number(p.price), yesNo_(p.active)
  ];
  if (!values[0] || !values[1] || !values[2] || !values[3] || !values[4] || !Number.isFinite(values[5])) throw new Error("Complete all product fields.");
  upsertByKey_(SHEETS.PRODUCTS, PRODUCT_HEADERS, 2, values);
  syncInventoryFromProducts_();
  return { ok: true, sku: values[1] };
}
function saveCatalogEntry_(entry) {
  const e = entry || {};
  const values = [
    String(e.productId || "").trim(), String(e.slug || "").trim(), String(e.name || "").trim(),
    String(e.description || "").trim(), String(e.badge || "").trim(), String(e.defaultColor || "").trim(),
    String(e.color || "").trim(), String(e.colorCode || "").trim().toUpperCase(),
    String(e.frontImage || "").trim(), String(e.backImage || "").trim(), Number(e.sortOrder || 999),
    yesNo_(e.featured), yesNo_(e.active)
  ];
  if (!values[0] || !values[1] || !values[2] || !values[6] || !values[7] || !values[8] || !values[9]) throw new Error("Complete the required catalog fields.");
  const key = values[0] + "|" + values[6];
  upsertByCompositeKey_(SHEETS.CATALOG, CATALOG_HEADERS, row => String(row[0]) + "|" + String(row[6]), key, values);
  return { ok: true, productId: values[0], color: values[6] };
}
function saveSetting_(key, value) {
  const k = String(key || "").trim();
  if (!k) throw new Error("Setting key is required.");
  upsertByKey_(SHEETS.SETTINGS, SETTINGS_HEADERS, 1, [k, String(value || "")]);
  return { ok: true, key: k, value: String(value || "") };
}
function publicCatalogResponse_() {
  return { ok: true, version: MIST_OS_VERSION, settings: settingsObject_(), products: buildPublicCatalog_() };
}
function buildPublicCatalog_() {
  const catalog = rowsAsObjects_(SHEETS.CATALOG, CATALOG_HEADERS, false);
  const products = productMap_();
  const grouped = {};
  catalog.forEach(row => {
    if (!isYes_(row.Active)) return;
    const productId = String(row["Product ID"] || "");
    const color = String(row.Color || "");
    const variants = Object.values(products).filter(v => v.active && v.productId === productId && v.color === color);
    if (!variants.length) return;
    if (!grouped[productId]) grouped[productId] = {
      id: row.Slug, productCode: productId, name: row["Product Name"], description: row.Description,
      badge: row.Badge, defaultColor: row["Default Color"], price: Math.min(...variants.map(v => v.price)),
      sizes: [], colors: {}, sortOrder: Number(row["Sort Order"] || 999), featured: isYes_(row.Featured)
    };
    variants.forEach(v => { if (!grouped[productId].sizes.includes(v.size)) grouped[productId].sizes.push(v.size); });
    grouped[productId].colors[color] = { code: row["Color Code"], front: row["Front Image URL"], back: row["Back Image URL"] };
  });
  const sizeOrder = ["XXS","XS","S","M","L","XL","XXL"];
  return Object.values(grouped).map(p => {
    p.sizes.sort((a,b) => sizeOrder.indexOf(a) - sizeOrder.indexOf(b));
    if (!p.colors[p.defaultColor]) p.defaultColor = Object.keys(p.colors)[0] || "";
    return p;
  }).sort((a,b) => a.sortOrder - b.sortOrder);
}
function productMap_() {
  const map = {};
  rowsAsObjects_(SHEETS.PRODUCTS, PRODUCT_HEADERS, false).forEach(r => {
    const sku = String(r.SKU || "").toUpperCase();
    if (!sku) return;
    map[sku] = { productId: r["Product ID"], sku, name: r["Product Name"], color: r.Color, size: r.Size, price: Number(r.Price || 0), active: isYes_(r.Active) };
  });
  return map;
}
function validateAndPriceItems_(rawItems, catalog) {
  if (!Array.isArray(rawItems) || !rawItems.length) throw new Error("The order has no items.");
  return rawItems.map(raw => {
    const sku = String(raw.sku || "").toUpperCase();
    const qty = Number(raw.qty);
    const p = catalog[sku];
    if (!p || !p.active || !Number.isInteger(qty) || qty < 1) throw new Error("Invalid or unavailable item: " + sku);
    return { ...p, qty, lineTotal: p.price * qty };
  });
}
