# MIST OS v2 Apps Script backend

The backend is split into modules to make maintenance safer:

- `00_Config.gs` — constants, sheet names, headers, defaults
- `01_Setup.gs` — setup, formatting, admin key
- `02_WebApp.gs` — public/admin API routes
- `03_Orders.gs` — orders, payment and status workflow
- `04_Products.gs` — SKU and website catalog management
- `05_Inventory.gs` — stock, reservations and deductions
- `06_Customers.gs` — customer aggregation
- `07_Reports.gs` — dashboard metrics
- `08_Utilities.gs` — shared helpers, logging, validation

## Two installation options

### Option A — Apps Script editor
Create one `.gs` file for each module and paste its matching content. Apps Script treats all `.gs` files in one project as a single codebase.

### Option B — one-file install
Paste `single-file/Code.gs` into the default Apps Script `Code.gs`. This is easier but less maintainable.

Run `setupMistOS()` once after installation.
