/**
 * MIST OS v2.0 — Google Apps Script backend
 * Run setupMistOS() once from a spreadsheet-bound Apps Script project.
 */

const MIST_OS_VERSION = "2.1.0";
const SCHEMA_VERSION = "MIST-OS-2.1";
const ORDER_PREFIX = "MIST";
const DUPLICATE_WINDOW_MINUTES = 30;
const ADMIN_KEY_PROPERTY = "MIST_OS_ADMIN_KEY";
const SPREADSHEET_ID_PROPERTY = "MIST_OS_SPREADSHEET_ID";

const SHEETS = Object.freeze({
  PRODUCTS: "Products",
  CATALOG: "Website Catalog",
  ORDERS: "Orders",
  ITEMS: "Order Items",
  INVENTORY: "Inventory",
  CUSTOMERS: "Customers",
  SETTINGS: "Website Settings",
  ERRORS: "Error Log"
});

const PRODUCT_HEADERS = ["Product ID", "SKU", "Product Name", "Color", "Size", "Price", "Active"];
const CATALOG_HEADERS = [
  "Product ID", "Slug", "Product Name", "Description", "Badge", "Default Color",
  "Color", "Color Code", "Front Image URL", "Back Image URL", "Sort Order", "Featured", "Active"
];
const ORDER_HEADERS = [
  "Submitted At", "Order Number", "Customer Name", "Email", "Mobile", "Delivery Address",
  "Total Quantity", "Subtotal", "Status", "Payment Status", "Duplicate Check",
  "Inventory State", "Notes", "Order Signature"
];
const ITEM_HEADERS = [
  "Submitted At", "Order Number", "Product ID", "SKU", "Product Name", "Color", "Size",
  "Quantity", "Unit Price", "Line Total"
];
const INVENTORY_HEADERS = ["SKU", "Product Name", "Color", "Size", "Stock", "Reserved", "Available"];
const CUSTOMER_HEADERS = ["Email", "Customer Name", "Mobile", "Orders", "Lifetime Spend", "Last Order"];
const SETTINGS_HEADERS = ["Key", "Value"];
const ERROR_HEADERS = ["Timestamp", "Function", "Order Number", "Error", "Details"];

const ORDER_STATUSES = ["New", "Suspicious", "Confirmed", "Packed", "Shipped", "Delivered", "Cancelled", "Duplicate"];
const PAYMENT_STATUSES = ["Pending", "Paid", "COD", "Refunded"];
const ALLOWED_TRANSITIONS = {
  New: ["Confirmed", "Cancelled", "Suspicious", "Duplicate"],
  Suspicious: ["Confirmed", "Cancelled", "Duplicate"],
  Confirmed: ["Packed", "Cancelled"],
  Packed: ["Shipped", "Cancelled"],
  Shipped: ["Delivered"],
  Delivered: [], Cancelled: [], Duplicate: []
};

const DEFAULT_PRODUCTS = (() => {
  const rows = [];
  const sizes = ["XS", "S", "M", "L", "XL"];
  const colors = [{name:"White",code:"WHT"},{name:"Black",code:"BLK"},{name:"Light Pink",code:"PNK"}];
  colors.forEach(c => sizes.forEach(size => rows.push(["AFS", `AFS-${c.code}-${size}`, "AirForm Studio Set", c.name, size, 899, "Yes"])));
  return rows;
})();

const DEFAULT_CATALOG = [
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","White","WHT","images/products/airform-studio-set/white/front.png","images/products/airform-studio-set/white/back.png",1,"Yes","Yes"],
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","Black","BLK","images/products/airform-studio-set/black/front.png","images/products/airform-studio-set/black/back.png",1,"Yes","Yes"],
  ["AFS","airform-studio-set","AirForm Studio Set","Sculpting support with a smooth, breathable feel for training, walking, and everyday movement.","NEW","White","Light Pink","PNK","images/products/airform-studio-set/light-pink/front.png","images/products/airform-studio-set/light-pink/back.png",1,"Yes","Yes"]
];

const DEFAULT_SETTINGS = [
  ["store_name", "MIST"],
  ["hero_title", "Move Light. Move Free."],
  ["hero_subtitle", "Activewear made for movement, confidence, and everyday life."],
  ["hero_button", "Shop the Collection"],
  ["hero_eyebrow", "The Airform Collection"],
  ["announcement_text", "MIST CATALOGUE · ORDERS ARE CONFIRMED MANUALLY BEFORE PAYMENT"],
  ["messenger_username", "marichris.milanes"],
  ["instagram_username", "Chrissygotosleep"],
  ["currency", "PHP"]
];
