/**
 * 03 Orders
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function createOrder_(payload) {
  validateCustomer_(payload);
  const ss = getSpreadsheet_();
  const products = productMap_();
  const items = validateAndPriceItems_(payload.items, products);
  const submittedAt = new Date();
  const signature = orderSignature_(payload, items);
  const duplicate = findLikelyDuplicate_(signature, submittedAt);
  const orderNumber = nextOrderNumber_();
  const qty = items.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
  const orders = ss.getSheetByName(SHEETS.ORDERS);
  orders.appendRow([
    submittedAt, orderNumber, payload.name.trim(), payload.email.trim(), payload.mobile.trim(), payload.address.trim(),
    qty, subtotal, duplicate ? "Suspicious" : "New", "Pending",
    duplicate ? "Possible duplicate of " + duplicate : "Clear", "NONE", String(payload.notes || "").trim(), signature
  ]);
  const itemsSheet = ss.getSheetByName(SHEETS.ITEMS);
  const rows = items.map(item => [submittedAt, orderNumber, item.productId, item.sku, item.name, item.color, item.size, item.qty, item.price, item.lineTotal]);
  itemsSheet.getRange(itemsSheet.getLastRow() + 1, 1, rows.length, ITEM_HEADERS.length).setValues(rows);
  rebuildCustomers_();
  return { ok: true, orderNumber, totalQuantity: qty, subtotal, possibleDuplicate: Boolean(duplicate) };
}
function updateOrderStatus_(orderNumber, newStatus) {
  const status = String(newStatus || "").trim();
  if (!ORDER_STATUSES.includes(status)) throw new Error("Invalid order status.");
  const ss = getSpreadsheet_();
  const orders = ss.getSheetByName(SHEETS.ORDERS);
  const row = findOrderRow_(orders, orderNumber);
  if (!row) throw new Error("Order not found: " + orderNumber);
  const oldStatus = String(orders.getRange(row, 9).getValue() || "New");
  if (oldStatus !== status && !(ALLOWED_TRANSITIONS[oldStatus] || []).includes(status)) {
    throw new Error(`Invalid status change: ${oldStatus} → ${status}`);
  }
  const currentState = String(orders.getRange(row, 12).getValue() || "NONE");
  const targetState = inventoryStateForStatus_(status);
  if (currentState === "SOLD" && targetState !== "SOLD") throw new Error("This order is already deducted from stock. Process a return manually.");
  if (currentState !== targetState) {
    transitionInventory_(orderItems_(orderNumber), currentState, targetState);
    orders.getRange(row, 12).setValue(targetState);
  }
  orders.getRange(row, 9).setValue(status);
  return { ok: true, orderNumber, status, inventoryState: targetState };
}
function updatePaymentStatus_(orderNumber, paymentStatus) {
  const status = String(paymentStatus || "").trim();
  if (!PAYMENT_STATUSES.includes(status)) throw new Error("Invalid payment status.");
  const sheet = getSpreadsheet_().getSheetByName(SHEETS.ORDERS);
  const row = findOrderRow_(sheet, orderNumber);
  if (!row) throw new Error("Order not found: " + orderNumber);
  sheet.getRange(row, 10).setValue(status);
  rebuildCustomers_();
  return { ok: true, orderNumber, paymentStatus: status };
}
function orderItems_(orderNumber) {
  return rowsAsObjects_(SHEETS.ITEMS, ITEM_HEADERS, false)
    .filter(r => r["Order Number"] === orderNumber)
    .map(r => ({ sku: String(r.SKU).toUpperCase(), quantity: Number(r.Quantity || 0) }));
}
function validateCustomer_(p) {
  if (!p.name || !p.email || !p.mobile || !p.address) throw new Error("Required customer information is missing.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(p.email))) throw new Error("Enter a valid email address.");
}
function orderSignature_(p, items) {
  return [String(p.email).toLowerCase(), normalizePhone_(p.mobile), items.map(i => `${i.sku}|${i.qty}`).sort().join(";")].join("::");
}
function findLikelyDuplicate_(signature, submittedAt) {
  const rows = rowsAsObjects_(SHEETS.ORDERS, ORDER_HEADERS, false);
  const cutoff = submittedAt.getTime() - DUPLICATE_WINDOW_MINUTES * 60000;
  for (let i = rows.length - 1; i >= 0; i--) {
    const when = new Date(rows[i]["Submitted At"]).getTime();
    if (when && when < cutoff) break;
    if (rows[i]["Order Signature"] === signature) return rows[i]["Order Number"];
  }
  return "";
}
function nextOrderNumber_() {
  const year = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy");
  const key = "ORDER_COUNTER_" + year;
  const props = PropertiesService.getScriptProperties();
  const next = Number(props.getProperty(key) || 0) + 1;
  props.setProperty(key, String(next));
  return `${ORDER_PREFIX}-${year}-${String(next).padStart(4,"0")}`;
}
