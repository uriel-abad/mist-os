/**
 * 08 Utilities
 * Part of MIST OS v2.0. Apps Script loads every .gs file as one project.
 */

function rowsAsObjects_(sheetName, headers, display) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const values = display ? sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getDisplayValues() : sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
  return values.filter(r => r.some(v => v !== "")).map(r => Object.fromEntries(headers.map((h,i) => [h,r[i]])));
}
function settingsObject_() {
  const out = {};
  rowsAsObjects_(SHEETS.SETTINGS, SETTINGS_HEADERS, false).forEach(r => out[String(r.Key)] = r.Value);
  return out;
}
function upsertByKey_(sheetName, headers, keyColumn, values) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  const row = findRowByValue_(sheet, keyColumn, values[keyColumn-1]);
  if (row) sheet.getRange(row,1,1,headers.length).setValues([values]); else sheet.appendRow(values);
}
function upsertByCompositeKey_(sheetName, headers, keyFn, targetKey, values) {
  const sheet = getSpreadsheet_().getSheetByName(sheetName);
  let row = 0;
  if (sheet.getLastRow() >= 2) {
    const rows = sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues();
    const index = rows.findIndex(r => keyFn(r) === targetKey); if (index >= 0) row = index + 2;
  }
  if (row) sheet.getRange(row,1,1,headers.length).setValues([values]); else sheet.appendRow(values);
}
function findOrderRow_(sheet, orderNumber) { return findRowByValue_(sheet,2,String(orderNumber)); }
function findRowByValue_(sheet, column, value) {
  if (!sheet || sheet.getLastRow() < 2) return 0;
  const found = sheet.getRange(2,column,sheet.getLastRow()-1,1).createTextFinder(String(value)).matchEntireCell(true).findNext();
  return found ? found.getRow() : 0;
}
function requireAdmin_(provided) {
  const expected = PropertiesService.getScriptProperties().getProperty(ADMIN_KEY_PROPERTY);
  if (!expected || String(provided || "") !== expected) throw new Error("Unauthorized admin request.");
}
function getSpreadsheet_() {
  const id = PropertiesService.getScriptProperties().getProperty(SPREADSHEET_ID_PROPERTY);
  if (id) return SpreadsheetApp.openById(id);
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) return active;
  throw new Error("Run setupMistOS first.");
}
function parsePayload_(e) {
  if (!e || !e.postData || !e.postData.contents) throw new Error("No request data received.");
  return JSON.parse(e.postData.contents);
}
function normalizePhone_(v) { return String(v || "").replace(/\D/g, ""); }
function isYes_(v) { return /^(yes|true|1|active)$/i.test(String(v || "").trim()); }
function yesNo_(v) { return isYes_(v) ? "Yes" : "No"; }
function errorMessage_(e) { return String(e && e.message || e); }
function json_(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function logError_(fn, order, error, details) {
  try { getSpreadsheet_().getSheetByName(SHEETS.ERRORS).appendRow([new Date(),fn,order,errorMessage_(error),String(details || "").slice(0,1000)]); } catch (_) {}
}
