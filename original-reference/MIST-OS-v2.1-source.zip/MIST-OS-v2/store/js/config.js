"use strict";

window.MIST = window.MIST || {};

MIST.config = {
  productsUrl: "data/products.json",
  useLiveCatalog: true,
  catalogAction: "catalog",
  // Your Facebook page username, e.g. "marichris.milanes" → m.me/marichris.milanes
  messengerUsername: "marichris.milanes",
  // Optional — leave as-is (or blank) if you don't want a spreadsheet backup log.
  // Orders still send fine through Messenger without it.
  gasEndpoint:
    "PASTE_YOUR_MIST_OS_WEB_APP_EXEC_URL",
};
