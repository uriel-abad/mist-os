# MIST OS v2.1 — Production Candidate

A separate lightweight commerce system for MIST.

## Why v2.1 instead of v1

- Modular backend files for easier maintenance
- Separate customer storefront and admin portal
- Admin API key kept out of GitHub
- Admin reads use POST so the key is not placed in the URL
- Product, catalog, inventory, order, customer, and website-settings management
- Storefront reads products and website settings from Google Sheets
- Local product JSON remains as a safe fallback

## Folders

- `store/` — customer-facing website
- `admin/` — admin portal
- `backend/apps-script/` — modular Apps Script backend
- `backend/apps-script/single-file/Code.gs` — easier copy-and-paste backend
- `docs/DEPLOYMENT.md` — deployment checklist

## Important security note

The `/admin/` page is publicly reachable on GitHub Pages, but data access requires the private admin key.
Do not commit the key. For stronger authentication later, move the admin portal behind a login provider or private hosting.

## Start

Read `docs/DEPLOYMENT.md`.
