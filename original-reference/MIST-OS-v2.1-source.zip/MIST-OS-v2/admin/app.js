"use strict";

const state = { endpoint: localStorage.getItem("mistOsEndpoint") || "", adminKey: localStorage.getItem("mistOsAdminKey") || "", orders: [] };
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const money = (n) => new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(Number(n || 0));
const esc = (v) => String(v ?? "").replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));

function toast(message) { const el = $("#toast"); el.textContent = message; el.hidden = false; clearTimeout(toast.timer); toast.timer = setTimeout(() => el.hidden = true, 3500); }
function connected() { return state.endpoint && state.adminKey; }
async function post(payload) {
  const r = await fetch(state.endpoint, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify({ ...payload, adminKey: state.adminKey }),
    redirect: "follow"
  });
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || "Request failed");
  return j;
}
async function read(action) { return post({ action }); }

function setView(name) { $$(".view").forEach(v => v.classList.toggle("active", v.id === `${name}View`)); $$(".nav").forEach(b => b.classList.toggle("active", b.dataset.view === name)); $("#pageTitle").textContent = name[0].toUpperCase()+name.slice(1); if (connected()) loadView(name); }

async function loadView(name) {
  try {
    $("#statusText").textContent = "Connected";
    if (name === "dashboard") renderDashboard((await read("dashboard")).dashboard);
    if (name === "orders") { state.orders = (await read("orders")).orders; renderOrders(); }
    if (name === "products") {
      const result = await read("products");
      renderProducts(result.products);
      renderCatalog(result.catalog || []);
    }
    if (name === "inventory") renderInventory((await read("inventory")).inventory);
    if (name === "customers") renderCustomers((await read("customers")).customers);
    if (name === "website") renderWebsiteSettings((await read("websiteSettings")).settings || {});
  } catch (e) { $("#statusText").textContent = e.message; toast(e.message); }
}

function renderDashboard(d) {
  const cards = [["Total orders",d.totalOrders],["Paid revenue",money(d.paidRevenue)],["Available units",d.available],["Low stock SKUs",d.lowStock],["Out of stock",d.outOfStock],["Reserved units",d.reserved],["Total stock",d.totalStock]];
  $("#cards").innerHTML = cards.map(([l,v]) => `<div class="card"><div class="label">${esc(l)}</div><div class="value">${esc(v)}</div></div>`).join("");
  $("#statusGrid").innerHTML = Object.entries(d.byStatus || {}).map(([s,n]) => `<div class="status-item"><span>${esc(s)}</span><strong>${n}</strong></div>`).join("");
}

function renderOrders() {
  const q = $("#orderSearch").value.toLowerCase(); const f = $("#statusFilter").value;
  const rows = state.orders.filter(o => (!f || o.Status === f) && (!q || [o["Order Number"],o["Customer Name"],o.Email,o.Mobile].join(" ").toLowerCase().includes(q)));
  $("#ordersBody").innerHTML = rows.map(o => `<tr><td>${esc(o["Order Number"])}</td><td>${esc(o["Customer Name"])}<br><small>${esc(o.Email)}</small></td><td>${money(o.Subtotal)}</td><td><select class="status-select" data-order="${esc(o["Order Number"])}">${statuses().map(s=>`<option ${s===o.Status?"selected":""}>${s}</option>`).join("")}</select></td><td><select class="payment-select" data-order="${esc(o["Order Number"])}">${payments().map(s=>`<option ${s===o["Payment Status"]?"selected":""}>${s}</option>`).join("")}</select></td><td>${esc(o["Submitted At"])}</td></tr>`).join("");
  $$(".status-select").forEach(el => el.onchange = async () => { try { await post({action:"updateOrderStatus",orderNumber:el.dataset.order,status:el.value}); toast("Order updated"); loadView("orders"); } catch(e){toast(e.message); loadView("orders");} });
  $$(".payment-select").forEach(el => el.onchange = async () => { try { await post({action:"updatePaymentStatus",orderNumber:el.dataset.order,paymentStatus:el.value}); toast("Payment updated"); } catch(e){toast(e.message);} });
}

function renderProducts(rows) { $("#productsBody").innerHTML = rows.map(p => `<tr><td>${esc(p.SKU)}</td><td>${esc(p["Product Name"])}</td><td>${esc(p.Color)}</td><td>${esc(p.Size)}</td><td>${money(p.Price)}</td><td>${esc(p.Active)}</td></tr>`).join(""); }
function renderCatalog(rows) {
  $("#catalogBody").innerHTML = rows.map(r => `<tr><td>${esc(r["Product Name"])}</td><td>${esc(r.Color)}</td><td>${esc(r.Badge)}</td><td>${esc(r["Sort Order"])}</td><td>${esc(r.Featured)}</td><td>${esc(r.Active)}</td></tr>`).join("");
}
function renderWebsiteSettings(settings) {
  const form = $("#websiteForm");
  Object.entries(settings || {}).forEach(([key, value]) => {
    if (form.elements[key]) form.elements[key].value = value ?? "";
  });
}
function renderInventory(rows) { $("#inventoryBody").innerHTML = rows.map(i => `<tr><td>${esc(i.SKU)}</td><td>${esc(i["Product Name"])}</td><td>${esc(i.Color)}</td><td>${esc(i.Size)}</td><td><input class="stock-input" type="number" min="0" value="${Number(i.Stock||0)}" data-sku="${esc(i.SKU)}"></td><td>${esc(i.Reserved)}</td><td>${esc(i.Available)}</td></tr>`).join(""); $$(".stock-input").forEach(el => el.onchange = async () => { try { await post({action:"updateStock",sku:el.dataset.sku,stock:Number(el.value)}); toast("Stock updated"); loadView("inventory"); } catch(e){toast(e.message);} }); }
function renderCustomers(rows) { $("#customersBody").innerHTML = rows.map(c => `<tr><td>${esc(c.Email)}</td><td>${esc(c["Customer Name"])}</td><td>${esc(c.Mobile)}</td><td>${esc(c.Orders)}</td><td>${money(c["Lifetime Spend"])}</td><td>${esc(c["Last Order"])}</td></tr>`).join(""); }
function statuses(){return ["New","Suspicious","Confirmed","Packed","Shipped","Delivered","Cancelled","Duplicate"]} function payments(){return ["Pending","Paid","COD","Refunded"]}

$("#settingsForm").onsubmit = e => { e.preventDefault(); const fd = new FormData(e.currentTarget); state.endpoint = String(fd.get("endpoint")).trim(); state.adminKey = String(fd.get("adminKey")).trim(); localStorage.setItem("mistOsEndpoint",state.endpoint); localStorage.setItem("mistOsAdminKey",state.adminKey); toast("Connection saved"); setView("dashboard"); };
$("#productForm").onsubmit = async e => { e.preventDefault(); try { const d=Object.fromEntries(new FormData(e.currentTarget)); await post({action:"saveProduct",product:d}); toast("SKU saved"); e.currentTarget.reset(); loadView("products"); } catch(err){toast(err.message);} };
$("#catalogForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const d = Object.fromEntries(new FormData(e.currentTarget));
    await post({ action: "saveCatalogEntry", entry: d });
    toast("Showcase saved");
    e.currentTarget.reset();
    loadView("products");
  } catch (err) { toast(err.message); }
};
$("#websiteForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const values = Object.fromEntries(new FormData(e.currentTarget));
    for (const [key, value] of Object.entries(values)) {
      await post({ action: "saveSetting", key, value });
    }
    toast("Website settings saved");
  } catch (err) { toast(err.message); }
};
$("#orderSearch").oninput = renderOrders; $("#statusFilter").onchange = renderOrders;
$("#connectBtn").onclick = () => setView("settings"); $("#refreshBtn").onclick = () => loadView($(".nav.active").dataset.view);
$$(".nav").forEach(b => b.onclick = () => setView(b.dataset.view));

statuses().forEach(s => $("#statusFilter").insertAdjacentHTML("beforeend",`<option>${s}</option>`));
$("#settingsForm").elements.endpoint.value = state.endpoint; $("#settingsForm").elements.adminKey.value = state.adminKey;
if (connected()) loadView("dashboard"); else setView("settings");
