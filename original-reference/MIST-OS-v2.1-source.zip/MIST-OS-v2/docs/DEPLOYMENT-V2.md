# Deploy MIST OS v2.1

Use a new Google Sheet and a new GitHub repository so your current live store stays untouched.

## 1. Install the Google Sheets backend

1. Create a new blank Google Sheet, such as **MIST OS Backend**.
2. Open **Extensions → Apps Script**.
3. Choose one method:

### Easiest
Copy `backend/apps-script/single-file/Code.gs` into the default `Code.gs`.

### Modular
Create and paste:
- `00_Config.gs`
- `01_Setup.gs`
- `02_WebApp.gs`
- `03_Orders.gs`
- `04_Products.gs`
- `05_Inventory.gs`
- `06_Customers.gs`
- `07_Reports.gs`
- `08_Utilities.gs`

Do not install both methods.

4. Save.
5. Run `setupMistOS()`.
6. Approve permissions.
7. Run `testMistOS()` and confirm `ok: true`.
8. Run `getAdminKey()` and save the key privately.

The manifest is optional. Ignore `appsscript.json` unless you specifically want to set timezone/scopes.

## 2. Deploy Apps Script

1. **Deploy → New deployment → Web app**
2. Execute as: **Me**
3. Who has access: **Anyone**
4. Deploy and copy the `/exec` URL.
5. Open it in a browser and confirm the health JSON.

## 3. Configure storefront

Open `store/js/config.js` and replace:

`PASTE_YOUR_MIST_OS_WEB_APP_EXEC_URL`

with the `/exec` URL.

## 4. Deploy GitHub Pages

1. Create a new repository, for example `mist-os`.
2. Upload this package to the repository root.
3. Enable **Settings → Pages** from the main branch/root.
4. URLs:
   - Store: `https://USERNAME.github.io/REPOSITORY/store/`
   - Admin: `https://USERNAME.github.io/REPOSITORY/admin/`

## 5. Connect admin

1. Open `/admin/`.
2. Open **Connection**.
3. Enter the `/exec` URL and private admin key.
4. Save.
5. Open Dashboard.

## 6. Test workflow

1. Enter stock.
2. Submit a test order.
3. Confirm Orders and Order Items populate.
4. New → Confirmed: Reserved increases.
5. Confirmed → Packed: reservation remains.
6. Packed → Shipped: Stock decreases and Reserved clears.
7. Test product, catalog, and website settings.
8. Refresh storefront and confirm updates.

## Product workflow

### Products
One row per sellable SKU:
- SKU
- Product ID/name
- Color
- Size
- Price
- Active

### Website Catalog
One row per product/color shown:
- Description
- Badge
- Default color
- Images
- Display order
- Featured/Active

New image files still need GitHub or another public image host. Paste their URL/path into Website Catalog.
