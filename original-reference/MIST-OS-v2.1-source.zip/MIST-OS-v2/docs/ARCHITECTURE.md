# MIST OS v2 architecture

## Storefront
`/store` is the public customer site. It reads products and settings from the Apps Script API and falls back to local JSON if the API is temporarily unavailable.

## Admin portal
`/admin` is the private management interface. It requires the Apps Script endpoint and admin key, stored only in that browser's local storage.

## Backend
`/backend/apps-script` contains modular Google Apps Script source files. Google Sheets remains the operational database.

## Core modules
- Orders
- Products and website catalog
- Inventory
- Customers
- Dashboard/reports
- Settings
- Error logging

## Data flow
Store/Admin → Apps Script Web App → Google Sheets

## Safety rules
- Never commit the admin key.
- Never expose the admin key in storefront code.
- Only Stock is manually set; Reserved and Available are calculated by workflow.
- Test status transitions before production deployment.
